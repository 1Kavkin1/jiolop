using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Test
{
    public partial class MainForm : Form
    {
        private int currentQuestionIndex = 0;
        private int score = 0;

        private List<Question> questions = new List<Question>
        {
            new Question
            {
                Text = "������� ������?",
                Answers = new[] { "����", "���", "�����", "�����" },
                CorrectAnswerIndex = 1
            },
            new Question
            {
                Text = "������ ���� 2 + 2?",
                Answers = new[] { "3", "4", "5", "22" },
                CorrectAnswerIndex = 1
            },
            new Question
            {
                Text = "��� ���� ��������������� � WinForms?",
                Answers = new[] { "Python", "C#", "HTML", "PHP" },
                CorrectAnswerIndex = 1
            },
            new Question
            {
                Text = "���� ������� ����� ��������������� ��� ������ ������� ������?",
                Answers = new[] { "Label", "Button", "RadioButton", "TextBox" },
                CorrectAnswerIndex = 2
            }
        };

        public MainForm()
        {
            InitializeComponent();

            rdBtnAnswer1.CheckedChanged += RadioButton_CheckedChanged;
            rdBtnAnswer2.CheckedChanged += RadioButton_CheckedChanged;
            rdBtnAnswer3.CheckedChanged += RadioButton_CheckedChanged;
            rdBtnAnswer4.CheckedChanged += RadioButton_CheckedChanged;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ShowQuestion();
        }

        private void ShowQuestion()
        {
            if (currentQuestionIndex < questions.Count)
            {
                Question question = questions[currentQuestionIndex];

                lbQuestion.Text = question.Text;

                rdBtnAnswer1.Text = question.Answers[0];
                rdBtnAnswer2.Text = question.Answers[1];
                rdBtnAnswer3.Text = question.Answers[2];
                rdBtnAnswer4.Text = question.Answers[3];

                rdBtnAnswer1.Checked = false;
                rdBtnAnswer2.Checked = false;
                rdBtnAnswer3.Checked = false;
                rdBtnAnswer4.Checked = false;

                btnNext.Enabled = false;
            }
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (sender is RadioButton radioButton && radioButton.Checked)
            {
                btnNext.Enabled = true;
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            int selectedAnswerIndex = -1;

            if (rdBtnAnswer1.Checked)
                selectedAnswerIndex = 0;
            else if (rdBtnAnswer2.Checked)
                selectedAnswerIndex = 1;
            else if (rdBtnAnswer3.Checked)
                selectedAnswerIndex = 2;
            else if (rdBtnAnswer4.Checked)
                selectedAnswerIndex = 3;

            if (selectedAnswerIndex == questions[currentQuestionIndex].CorrectAnswerIndex)
            {
                score++;
            }

            currentQuestionIndex++;

            if (currentQuestionIndex < questions.Count)
            {
                ShowQuestion();
            }
            else
            {
                MessageBox.Show(
                    $"���� ���������!\n���������� ��������: {score} � {questions.Count}",
                    "���������",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                currentQuestionIndex = 0;
                score = 0;
                ShowQuestion();
            }
        }
    }

    public class Question
    {
        public string Text { get; set; }
        public string[] Answers { get; set; }
        public int CorrectAnswerIndex { get; set; }
    }
}