﻿namespace Test
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lbQuestion;
        private System.Windows.Forms.RadioButton rdBtnAnswer1;
        private System.Windows.Forms.RadioButton rdBtnAnswer2;
        private System.Windows.Forms.RadioButton rdBtnAnswer3;
        private System.Windows.Forms.RadioButton rdBtnAnswer4;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.GroupBox groupBoxAnswers;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lbQuestion = new System.Windows.Forms.Label();
            this.rdBtnAnswer1 = new System.Windows.Forms.RadioButton();
            this.rdBtnAnswer2 = new System.Windows.Forms.RadioButton();
            this.rdBtnAnswer3 = new System.Windows.Forms.RadioButton();
            this.rdBtnAnswer4 = new System.Windows.Forms.RadioButton();
            this.btnNext = new System.Windows.Forms.Button();
            this.groupBoxAnswers = new System.Windows.Forms.GroupBox();
            this.groupBoxAnswers.SuspendLayout();
            this.SuspendLayout();

            // lbQuestion
            this.lbQuestion.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lbQuestion.Location = new System.Drawing.Point(30, 25);
            this.lbQuestion.Name = "lbQuestion";
            this.lbQuestion.Size = new System.Drawing.Size(520, 70);
            this.lbQuestion.TabIndex = 0;
            this.lbQuestion.Text = "Питання";
            this.lbQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // groupBoxAnswers
            this.groupBoxAnswers.Controls.Add(this.rdBtnAnswer1);
            this.groupBoxAnswers.Controls.Add(this.rdBtnAnswer2);
            this.groupBoxAnswers.Controls.Add(this.rdBtnAnswer3);
            this.groupBoxAnswers.Controls.Add(this.rdBtnAnswer4);
            this.groupBoxAnswers.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.groupBoxAnswers.Location = new System.Drawing.Point(50, 110);
            this.groupBoxAnswers.Name = "groupBoxAnswers";
            this.groupBoxAnswers.Size = new System.Drawing.Size(480, 190);
            this.groupBoxAnswers.TabIndex = 1;
            this.groupBoxAnswers.TabStop = false;
            this.groupBoxAnswers.Text = "Варіанти відповіді";

            // rdBtnAnswer1
            this.rdBtnAnswer1.AutoSize = true;
            this.rdBtnAnswer1.Location = new System.Drawing.Point(30, 35);
            this.rdBtnAnswer1.Name = "rdBtnAnswer1";
            this.rdBtnAnswer1.Size = new System.Drawing.Size(91, 23);
            this.rdBtnAnswer1.TabIndex = 0;
            this.rdBtnAnswer1.TabStop = true;
            this.rdBtnAnswer1.Text = "Варіант 1";
            this.rdBtnAnswer1.UseVisualStyleBackColor = true;

            // rdBtnAnswer2
            this.rdBtnAnswer2.AutoSize = true;
            this.rdBtnAnswer2.Location = new System.Drawing.Point(30, 75);
            this.rdBtnAnswer2.Name = "rdBtnAnswer2";
            this.rdBtnAnswer2.Size = new System.Drawing.Size(91, 23);
            this.rdBtnAnswer2.TabIndex = 1;
            this.rdBtnAnswer2.TabStop = true;
            this.rdBtnAnswer2.Text = "Варіант 2";
            this.rdBtnAnswer2.UseVisualStyleBackColor = true;

            // rdBtnAnswer3
            this.rdBtnAnswer3.AutoSize = true;
            this.rdBtnAnswer3.Location = new System.Drawing.Point(30, 115);
            this.rdBtnAnswer3.Name = "rdBtnAnswer3";
            this.rdBtnAnswer3.Size = new System.Drawing.Size(91, 23);
            this.rdBtnAnswer3.TabIndex = 2;
            this.rdBtnAnswer3.TabStop = true;
            this.rdBtnAnswer3.Text = "Варіант 3";
            this.rdBtnAnswer3.UseVisualStyleBackColor = true;

            // rdBtnAnswer4
            this.rdBtnAnswer4.AutoSize = true;
            this.rdBtnAnswer4.Location = new System.Drawing.Point(30, 155);
            this.rdBtnAnswer4.Name = "rdBtnAnswer4";
            this.rdBtnAnswer4.Size = new System.Drawing.Size(91, 23);
            this.rdBtnAnswer4.TabIndex = 3;
            this.rdBtnAnswer4.TabStop = true;
            this.rdBtnAnswer4.Text = "Варіант 4";
            this.rdBtnAnswer4.UseVisualStyleBackColor = true;

            // btnNext
            this.btnNext.Enabled = false;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnNext.Location = new System.Drawing.Point(200, 325);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(180, 45);
            this.btnNext.TabIndex = 2;
            this.btnNext.Text = "Далі";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);

            // MainForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 401);
            this.Controls.Add(this.lbQuestion);
            this.Controls.Add(this.groupBoxAnswers);
            this.Controls.Add(this.btnNext);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Програма для тестування";
            this.Load += new System.EventHandler(this.MainForm_Load);

            this.groupBoxAnswers.ResumeLayout(false);
            this.groupBoxAnswers.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}